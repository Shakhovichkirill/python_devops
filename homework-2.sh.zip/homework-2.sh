#!/bin/bash

if grep "ConditionPathExists" /lib/systemd/system/ssh.service; then
sed -i '/After/a Requisite=vsftpd.service' /lib/systemd/system/ssh.service
else
sed -i '/After/a Requisite=vsftpd.service\nConditionPathExists=!/etc/ssh/sshd_not_to_be_run' /lib/systemd/system/ssh.service
fi
systemctl daemon-reload
systemctl stop sshd.service

echo "root:$(date +%s | sha256sum | base64 | head -c 32)" | chpasswd

touch /etc/ssh/sshd_not_to_be_run
chmod 000 /usr/sbin/sshd

echo "The server will reboot in 7 seconds. Good luck"

sleep 7
reboot
