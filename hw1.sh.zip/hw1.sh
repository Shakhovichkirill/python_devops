#!/bin/bash

user=hw1

useradd ${user} -s /bin/false  -m
echo "DONE" > /home/${user}/test.file
chmod 600 /home/${user}/test.file
chown hw1:hw1 /home/${user}/test.file
sed -i -e "s/$(cat /etc/passwd |grep hw1 |grep -Eo '[[:digit:]]{4}' |uniq)/9999/g" /etc/passwd

mkdir -p /test
mount -t tmpfs -o size=512m tmpfs /test
dd if=/dev/zero of=/test/test bs=1M count=500M &>/dev/null
mount -t tmpfs -o size=512m tmpfs /test

echo "while true ;do true; done" > ~/cpu.sh
nohup bash ~/cpu.sh &>/dev/null &
